function [signalA, signalB, fs, fullPath] = load_pico_data_dual(hardware_gain, filename)
% LOAD_PICO_DATA_DUAL 加载并预处理PicoScope双通道数据
% 输入:
%   hardware_gain - 硬件增益系数 (必需)
%   filename      - 文件路径 (可选)
% 输出:
%   signalA       - 处理后的通道 A 信号 (物理量)
%   signalB       - 处理后的通道 B 信号 (物理量)
%   fs            - 采样率 (Hz)

    % 1. 文件路径获取
    if nargin < 2 || isempty(filename)
        [fileName, filePath] = uigetfile('*.mat', '选择双通道 PicoScope 数据文件');
        if isequal(fileName, 0)
            warning('未选择文件，函数已退出。');
            signalA = []; signalB = []; fs = [];
            return;
        end
        fullPath = fullfile(filePath, fileName);
    else
        fullPath = filename;
        if ~exist(fullPath, 'file')
            error('找不到指定文件: %s', fullPath);
        end
    end

    % 2. 加载数据
    fprintf('读取数据中: %s\n', fullPath);
    try
        % 动态检查变量 A, B 和 Tinterval
        vars = load(fullPath);
        if ~isfield(vars, 'A') || ~isfield(vars, 'B') || ~isfield(vars, 'Tinterval')
            error('MAT 文件中必须同时包含变量 "A", "B" 和 "Tinterval"');
        end
        
        rawA = double(vars.A);
        rawB = double(vars.B);
        Tinterval = vars.Tinterval;
        fs = 1 / Tinterval;
    catch ME
        rethrow(ME);
    end

    % 3. 同步清洗与预处理
    % 1) 物理量转换
    signalA = rawA / hardware_gain;
    signalB = rawB / hardware_gain;

    % 2) 长度对齐 (防止硬件采集时产生的 1-2 个 sample 误差)
    minLength = min(length(signalA), length(signalB));
    signalA = signalA(1:minLength);
    signalB = signalB(1:minLength);

    % 3) 同步剔除无效值 (确保 A 和 B 的样本点依然一一对应)
    validIdx = isfinite(signalA) & isfinite(signalB);
    signalA = signalA(validIdx);
    signalB = signalB(validIdx);

    % 4) 去直流 (均值中心化)
    signalA = detrend(signalA, 'constant');
    signalB = detrend(signalB, 'constant');

    fprintf('处理完成: 采样率 %.2f MHz, 样本点数 %d\n', fs/1e6, length(signalA));
end