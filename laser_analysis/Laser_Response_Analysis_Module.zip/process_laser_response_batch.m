%% 通用激光器频率响应批处理
% 处理 A 通道拍频、B 通道正弦注入的 PicoScope MAT 数据。
% 推荐通过 analyze_laser_response.m 调用本脚本。
if exist('laser_response_config', 'var') && isstruct(laser_response_config)
    run_config = laser_response_config;
else
    run_config = struct();
end
clearvars -except run_config;

script_fullpath = mfilename('fullpath');
script_dir = fileparts(script_fullpath);
if isempty(script_dir)
    script_dir = pwd;
end
addpath(script_dir);

%% 1. 数据与输出路径
data_path = get_config(run_config, 'DataPath', '');
if isempty(data_path)
    if usejava('desktop')
        data_path = uigetdir(pwd, '选择激光器响应 MAT 数据目录');
        if isequal(data_path, 0)
            error('未选择数据目录。');
        end
    else
        error('必须通过配置项 DataPath 指定数据目录。');
    end
end
if ~isfolder(data_path)
    if usejava('desktop')
        selected_path = uigetdir(fileparts(script_dir), ...
            '选择 698 激光器响应数据目录');
        if isequal(selected_path, 0)
            error('未选择数据目录。');
        end
        data_path = selected_path;
    else
        error('数据目录不存在: %s', data_path);
    end
end

save_filepath = get_config(run_config, 'OutputPath', ...
    fullfile(data_path, 'processed_results'));
if ~isfolder(save_filepath)
    mkdir(save_filepath);
end

%% 2. 自动发现并按调制频率排序
file_pattern = get_config(run_config, 'FilePattern', ...
    'A_beat_B_sin_*.mat');
expected_file_count = get_config(run_config, 'ExpectedFileCount', 0);
output_tag = get_config(run_config, 'OutputTag', 'laser_response');
figure_title = get_config(run_config, 'FigureTitle', ...
    'Laser Frequency Response');
file_list = get_config(run_config, 'FileList', {});
if isempty(file_list)
    listing = dir(fullfile(data_path, file_pattern));
    if isempty(listing)
        error('数据目录中没有找到 %s。', file_pattern);
    end
    file_list = arrayfun(@(x) fullfile(x.folder, x.name), listing, ...
        'UniformOutput', false);
else
    if isstring(file_list)
        file_list = cellstr(file_list);
    elseif ischar(file_list)
        file_list = {file_list};
    end
    if ~iscell(file_list)
        error('FileList 必须是字符向量、字符串数组或元胞数组。');
    end
    for ii = 1:numel(file_list)
        if isstring(file_list{ii})
            file_list{ii} = char(file_list{ii});
        end
        [file_folder, ~, ~] = fileparts(file_list{ii});
        if isempty(file_folder)
            file_list{ii} = fullfile(data_path, file_list{ii});
        end
        if ~isfile(file_list{ii})
            error('FileList 中的文件不存在: %s', file_list{ii});
        end
    end
end
file_list = file_list(:);
nominal_frequency = cellfun(@parse_modulation_frequency, file_list);
nominal_frequency = nominal_frequency(:);
[nominal_frequency, order] = sort(nominal_frequency);
file_list = file_list(order);

if expected_file_count > 0 && numel(file_list) ~= expected_file_count
    warning('预期 %d 个频点，实际发现 %d 个；仍继续处理现有文件。', ...
        expected_file_count, numel(file_list));
end
fprintf('数据目录: %s\n', data_path);
fprintf('输出目录: %s\n', save_filepath);
fprintf('发现 %d 个输入文件，频率范围 %.6g Hz 至 %.6g Hz。\n\n', ...
    numel(file_list), min(nominal_frequency), max(nominal_frequency));

%% 3. 处理参数
% 该值只用于记录载波偏差；实际载波对每个文件自动估计。
f_carrier_hint = get_config(run_config, 'CarrierHintHz', 20e6);
digital_mod_amp = get_config(run_config, 'DigitalModAmp', 0);
response_polarity = get_config(run_config, 'ResponsePolarity', +1);
phase_ambiguity_180 = logical(get_config( ...
    run_config, 'PhaseAmbiguity180', false));
phase_target_deg = get_config(run_config, 'PhaseTargetDeg', -90);
magnitude_outlier_threshold_dB = get_config( ...
    run_config, 'MagnitudeOutlierThresholddB', 12);

%% 4. 逐文件处理
num_files = numel(file_list);
valid_flags = false(num_files, 1);
error_message = strings(num_files, 1);
D_coeff_array = nan(num_files, 1);
phase_diff_array = nan(num_files, 1);
f_mod_est_array = nan(num_files, 1);
response_array = complex(nan(num_files, 1), nan(num_files, 1));
carrier_array = nan(num_files, 1);
input_amp_array = nan(num_files, 1);
input_unit_array = strings(num_files, 1);
phase_fit_ratio_array = nan(num_files, 1);
phase_coherent_snr_array = nan(num_files, 1);
input_coherent_snr_array = nan(num_files, 1);
demodulation_method_array = strings(num_files, 1);
quality_flag_array = strings(num_files, 1);

for ii = 1:num_files
    current_file = file_list{ii};
    fprintf('正在处理 [%d/%d]: %s\n', ii, num_files, current_file);
    try
        [D_coeff_array(ii), phase_diff_array(ii), f_mod_est_array(ii), ...
            diagnostics] = process_pdh_data_adaptive( ...
            current_file, f_carrier_hint, digital_mod_amp);

        response_array(ii) = response_polarity * ...
            diagnostics.response_phasor;
        phase_diff_array(ii) = angle(response_array(ii))*180/pi;
        carrier_array(ii) = diagnostics.f_carrier_est_Hz;
        input_amp_array(ii) = diagnostics.input_amplitude;
        input_unit_array(ii) = string(diagnostics.input_unit);
        phase_fit_ratio_array(ii) = ...
            diagnostics.phase_tone_to_residual_dB;
        phase_coherent_snr_array(ii) = ...
            diagnostics.phase_coherent_snr_dB;
        input_coherent_snr_array(ii) = ...
            diagnostics.input_coherent_snr_dB;
        demodulation_method_array(ii) = ...
            string(diagnostics.demodulation_method);
        quality_flag_array(ii) = quality_from_snr( ...
            phase_coherent_snr_array(ii), ...
            input_coherent_snr_array(ii));
        valid_flags(ii) = true;
    catch ME
        error_message(ii) = string(ME.message);
        quality_flag_array(ii) = "PROCESSING_FAILED";
        fprintf(2, '处理失败: %s\n', ME.message);
    end
    fprintf('--------------------------------------------------\n');
end

if ~any(valid_flags)
    error('所有文件均处理失败，请检查上方错误信息。');
end

% 相干 SNR 会随记录长度提高，可能漏掉“统计上显著、但明显偏离相邻频点”
% 的孤立响应。这里只增加检查标记，不删除、平滑或替换原始结果。
local_magnitude_deviation_array = local_magnitude_deviation_dB( ...
    f_mod_est_array, abs(response_array), valid_flags);
magnitude_outlier_flags = valid_flags & ...
    abs(local_magnitude_deviation_array) > magnitude_outlier_threshold_dB;
quality_flag_array(magnitude_outlier_flags & quality_flag_array == "OK") = ...
    "CHECK_MAGNITUDE_OUTLIER";

%% 5. 明细结果
ResultTable = table(file_list, nominal_frequency, valid_flags, ...
    f_mod_est_array, carrier_array, input_amp_array, input_unit_array, ...
    D_coeff_array, abs(response_array), real(response_array), ...
    imag(response_array), phase_diff_array, ...
    local_magnitude_deviation_array, phase_fit_ratio_array, ...
    phase_coherent_snr_array, input_coherent_snr_array, ...
    demodulation_method_array, quality_flag_array, error_message, ...
    'VariableNames', {'FileName', 'Nominal_Frequency_Hz', 'Valid', ...
    'F_mod_Hz', 'Carrier_Hz', 'Input_Amplitude', 'Input_Unit', ...
    'D_coeff_Input_per_Hz', 'Response_Hz_per_Input', ...
    'Response_Real', 'Response_Imag', 'Phase_Diff_deg', ...
    'Local_Magnitude_Deviation_dB', ...
    'Phase_Tone_to_Residual_dB', 'Phase_Coherent_SNR_dB', ...
    'Input_Coherent_SNR_dB', 'Demodulation_Method', ...
    'Quality_Flag', 'ErrorMessage'});

%% 6. 按频率进行复响应聚合
success_index = find(valid_flags);
f_success = f_mod_est_array(success_index);
response_success = response_array(success_index);
carrier_success = carrier_array(success_index);
input_success = input_amp_array(success_index);
phase_snr_success = phase_coherent_snr_array(success_index);

[f_success, sort_index] = sort(f_success);
response_success = response_success(sort_index);
carrier_success = carrier_success(sort_index);
input_success = input_success(sort_index);
phase_snr_success = phase_snr_success(sort_index);
[f_mod_use, ~, group_index] = unique(f_success);

H_mean = accumarray(group_index, real(response_success), [], @mean) + ...
    1i*accumarray(group_index, imag(response_success), [], @mean);
response_mean = abs(H_mean);
D_mean = 1./response_mean;
if phase_ambiguity_180
    % 拍频只能给出频差绝对值；当两束光的频率顺序翻转时，响应会多出
    % 180 度符号跳变。对二倍相位展开后再除以二，可连续选择正确分支。
    phi_mean = unwrap(2*angle(H_mean))/2*180/pi;
    phi_mean = phi_mean - 180*round(phi_mean(1)/180);
else
    phi_mean = unwrap(angle(H_mean))*180/pi;
end
phase_minus90_frequency_Hz = find_phase_crossing_log( ...
    f_mod_use, phi_mean, phase_target_deg);
repeat_count = accumarray(group_index, 1, [], @sum);
carrier_mean = accumarray(group_index, carrier_success, [], @mean);
input_amplitude_mean = accumarray(group_index, input_success, [], @mean);
phase_coherent_snr_mean = accumarray( ...
    group_index, phase_snr_success, [], @mean);
response_coherence = accumarray(group_index, abs(response_success), [], ...
    @mean);
response_coherence = response_mean./response_coherence;

SummaryTable = table(f_mod_use, repeat_count, response_mean, D_mean, ...
    phi_mean, carrier_mean, input_amplitude_mean, ...
    phase_coherent_snr_mean, response_coherence, ...
    'VariableNames', {'F_mod_Hz', 'RepeatCount', ...
    'Response_mean_Hz_per_Input', 'D_mean_Input_per_Hz', ...
    'Phase_mean_deg', 'Carrier_mean_Hz', 'Input_Amplitude_mean', ...
    'Phase_Coherent_SNR_mean_dB', 'Response_Coherence'});

disp(SummaryTable);

%% 7. 绘图与保存
time_string = char(datetime('now', 'Format', 'yyyyMMdd_HHmmss'));
figure_file = fullfile(save_filepath, sprintf( ...
    'Laser_Response_%s_%s.png', output_tag, time_string));
detail_csv = fullfile(save_filepath, sprintf( ...
    'PDH_Batch_Result_%s_%s.csv', output_tag, time_string));
summary_csv = fullfile(save_filepath, sprintf( ...
    'PDH_Frequency_Summary_%s_%s.csv', output_tag, time_string));
mat_file = fullfile(save_filepath, sprintf( ...
    'PDH_Statistics_%s_%s.mat', output_tag, time_string));

fig = figure('Color', 'w', 'Name', figure_title, ...
    'Position', [100, 100, 900, 650]);
yyaxis left;
plot(f_mod_use/1e6, response_mean, '-o', 'LineWidth', 1.5, ...
    'MarkerSize', 5, 'MarkerFaceColor', 'auto');
set(gca, 'XScale', 'log', 'YScale', 'log');
xlabel('Modulation Frequency (MHz)', 'FontWeight', 'bold');
ylabel('Laser Response (Hz/V)', 'FontWeight', 'bold');
grid on;
yyaxis right;
plot(f_mod_use/1e6, phi_mean, '-s', 'LineWidth', 1.5, ...
    'MarkerSize', 5, 'Color', '#D95319', ...
    'MarkerFaceColor', 'auto');
hold on;
ylabel('Response Phase (deg)', 'FontWeight', 'bold');
yline(phase_target_deg, ':', sprintf('%g deg', phase_target_deg), ...
    'Color', [0.35, 0.35, 0.35], 'LineWidth', 1.2, ...
    'LabelHorizontalAlignment', 'left');
if isfinite(phase_minus90_frequency_Hz)
    crossing_MHz = phase_minus90_frequency_Hz/1e6;
    xline(crossing_MHz, '--k', sprintf('%.3f MHz', crossing_MHz), ...
        'LineWidth', 1.3, 'LabelOrientation', 'horizontal', ...
        'LabelVerticalAlignment', 'middle');
    plot(crossing_MHz, phase_target_deg, 'kp', ...
        'MarkerFaceColor', '#EDB120', 'MarkerSize', 10);
end
title(figure_title, 'FontWeight', 'bold');
exportgraphics(fig, figure_file, 'Resolution', 300);

writetable(ResultTable, detail_csv);
writetable(SummaryTable, summary_csv);
[per_file_output_dir, PerFileManifest] = ...
    export_laser_per_file_results(ResultTable, SummaryTable, save_filepath);
save(mat_file, 'ResultTable', 'SummaryTable', 'f_mod_use', 'H_mean', ...
    'response_mean', 'D_mean', 'phi_mean', 'carrier_mean', ...
    'input_amplitude_mean', 'phase_coherent_snr_mean', ...
    'response_coherence', 'response_polarity', 'f_carrier_hint', ...
    'digital_mod_amp', 'phase_ambiguity_180', 'phase_target_deg', ...
    'magnitude_outlier_threshold_dB', ...
    'phase_minus90_frequency_Hz', 'PerFileManifest', ...
    'per_file_output_dir', 'data_path', 'save_filepath');

fprintf('\n处理完成: %d/%d 个文件成功。\n', nnz(valid_flags), num_files);
fprintf('明细 CSV : %s\n', detail_csv);
fprintf('频点汇总 : %s\n', summary_csv);
fprintf('统计 MAT : %s\n', mat_file);
fprintf('响应图   : %s\n', figure_file);
fprintf('逐文件输出: %s\n', per_file_output_dir);
if isfinite(phase_minus90_frequency_Hz)
    fprintf('%g 度相位频率: %.9g Hz (%.6f MHz)\n', ...
        phase_target_deg, phase_minus90_frequency_Hz, ...
        phase_minus90_frequency_Hz/1e6);
else
    fprintf('当前有效频率范围内没有找到 %g 度相位交点。\n', ...
        phase_target_deg);
end

%% 局部函数
function frequency = parse_modulation_frequency(filename)
    token = regexp(filename, '([0-9]*\.?[0-9]+)\s*(k|m)?Hz', ...
        'tokens', 'once', 'ignorecase');
    if isempty(token)
        error('无法从文件名解析调制频率: %s', filename);
    end
    frequency = str2double(token{1});
    unit = lower(token{2});
    if strcmp(unit, 'k')
        frequency = frequency*1e3;
    elseif strcmp(unit, 'm')
        frequency = frequency*1e6;
    end
end

function flag = quality_from_snr(phase_snr_dB, input_snr_dB)
    if ~isfinite(phase_snr_dB) || ~isfinite(input_snr_dB)
        flag = "INVALID_SNR";
    elseif input_snr_dB < 10
        flag = "LOW_INPUT_SNR";
    elseif phase_snr_dB < 0
        flag = "LOW_PHASE_SNR";
    elseif phase_snr_dB < 10
        flag = "MARGINAL_PHASE_SNR";
    else
        flag = "OK";
    end
end

function crossing_frequency = find_phase_crossing_log( ...
        frequency, phase_deg, target_phase_deg)
    crossing_frequency = NaN;
    frequency = frequency(:);
    phase_deg = phase_deg(:);
    valid = isfinite(frequency) & frequency > 0 & isfinite(phase_deg);
    frequency = frequency(valid);
    phase_deg = phase_deg(valid);
    if numel(frequency) < 2
        return;
    end

    difference = phase_deg - target_phase_deg;
    exact_index = find(difference == 0, 1, 'first');
    if ~isempty(exact_index)
        crossing_frequency = frequency(exact_index);
        return;
    end
    bracket_index = find(difference(1:end-1).*difference(2:end) < 0, ...
        1, 'first');
    if isempty(bracket_index)
        return;
    end

    interpolation_fraction = -difference(bracket_index)/ ...
        (difference(bracket_index + 1) - difference(bracket_index));
    log_frequency = log10(frequency(bracket_index)) + ...
        interpolation_fraction*(log10(frequency(bracket_index + 1)) - ...
        log10(frequency(bracket_index)));
    crossing_frequency = 10^log_frequency;
end

function value = get_config(config, field_name, default_value)
    if isfield(config, field_name) && ~isempty(config.(field_name))
        value = config.(field_name);
    else
        value = default_value;
    end
end

function deviation_dB = local_magnitude_deviation_dB( ...
        frequency, response_magnitude, valid_flags)
    deviation_dB = nan(size(frequency));
    valid_index = find(valid_flags & isfinite(frequency) & frequency > 0 & ...
        isfinite(response_magnitude) & response_magnitude > 0);
    if numel(valid_index) < 3
        return;
    end

    [frequency_sorted, order] = sort(frequency(valid_index));
    response_sorted = response_magnitude(valid_index(order));
    [frequency_unique, ~, group_index] = unique(frequency_sorted);
    response_group = accumarray(group_index, response_sorted, [], @mean);
    group_deviation_dB = nan(size(frequency_unique));

    for ii = 2:numel(frequency_unique)-1
        neighbor_index = [ii-1, ii+1];
        predicted_log_response = interp1( ...
            log10(frequency_unique(neighbor_index)), ...
            log10(response_group(neighbor_index)), ...
            log10(frequency_unique(ii)));
        group_deviation_dB(ii) = 20*( ...
            log10(response_group(ii)) - predicted_log_response);
    end

    sorted_deviation = group_deviation_dB(group_index);
    deviation_dB(valid_index(order)) = sorted_deviation;
end
