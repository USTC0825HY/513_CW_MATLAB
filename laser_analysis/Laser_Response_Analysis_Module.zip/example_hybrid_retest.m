%% 混合示例：低频使用旧文件，高频使用带 _new 后缀的重测文件
module_dir = fileparts(mfilename('fullpath'));
addpath(module_dir);

data_path = uigetdir(pwd, '选择同时包含旧数据和 _new 数据的目录');
if isequal(data_path, 0)
    error('未选择数据目录。');
end

switch_frequency_Hz = 1e6;
listing = dir(fullfile(data_path, 'A_beat_B_sin_*.mat'));
names = {listing.name}';
frequency_Hz = cellfun(@parse_frequency, names);
is_retest = contains(names, '_new', 'IgnoreCase', true);
use_file = (~is_retest & frequency_Hz < switch_frequency_Hz) | ...
    (is_retest & frequency_Hz >= switch_frequency_Hz);
selected = listing(use_file);
selected_frequency_Hz = frequency_Hz(use_file);

[unique_frequency_Hz, ~, group] = unique(selected_frequency_Hz);
if numel(unique_frequency_Hz) ~= numel(selected_frequency_Hz) || ...
        any(accumarray(group, 1) ~= 1)
    error('混合选择后存在重复频点，请检查文件名和切换频率。');
end

file_list = arrayfun(@(x) fullfile(x.folder, x.name), selected, ...
    'UniformOutput', false);
options = struct( ...
    'FileList', {file_list}, ...
    'OutputPath', fullfile(data_path, 'processed_results_hybrid'), ...
    'OutputTag', 'laser_response_hybrid', ...
    'FigureTitle', 'Laser Response: old low frequency + new high frequency', ...
    'ExpectedFileCount', numel(file_list), ...
    'CarrierHintHz', 20e6, ...
    'DigitalModAmp', 0, ...
    'ResponsePolarity', +1, ...
    'PhaseAmbiguity180', true, ...
    'PhaseTargetDeg', -90);

result = analyze_laser_response(data_path, options);
disp(result.SummaryTable);

function frequency_Hz = parse_frequency(filename)
    token = regexp(filename, '([0-9]*\.?[0-9]+)\s*(k|m)?Hz', ...
        'tokens', 'once', 'ignorecase');
    if isempty(token)
        error('无法从文件名读取调制频率: %s', filename);
    end
    frequency_Hz = str2double(token{1});
    if strcmpi(token{2}, 'k')
        frequency_Hz = frequency_Hz*1e3;
    elseif strcmpi(token{2}, 'm')
        frequency_Hz = frequency_Hz*1e6;
    end
end
