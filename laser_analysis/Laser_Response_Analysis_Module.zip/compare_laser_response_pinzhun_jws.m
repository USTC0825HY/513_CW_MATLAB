%% Pinzhun 与 JWS 激光器频率响应对比
% 将本脚本与两份 PDH_Statistics_laser_*.mat 放在同一目录后直接运行。
% 脚本不依赖 MATLAB 当前工作目录，会自动从自身所在目录加载数据并保存结果。

clear; close all; clc;

script_path = mfilename('fullpath');
script_dir = fileparts(script_path);
if isempty(script_dir)
    script_dir = pwd;
end
analysis_dir = fileparts(script_dir);
addpath(analysis_dir); % align_phase.m 使用的 Bode CSV 读取和复数插值函数

datasets = struct( ...
    'Label', {'Pinzhun corrected (23 MHz BPF)', 'JWS'}, ...
    'ShortLabel', {'Pinzhun', 'JWS'}, ...
    'FileName', { ...
        'PDH_Statistics_laser_pinzhun_20260712_180128.mat', ...
        'PDH_Statistics_laser_jws_20260806_095152.mat'}, ...
    'ApplyBandpassCompensation', {true, false}, ...
    'CarrierHz', {23e6, NaN}, ...
    'FilterBodeFile', { ...
        '10M_30M带通加10dB衰减-2_2026-07-03T20_54_48.csv', ''}, ...
    'LineStyle', {'-', '--'}, ...
    'Marker', {'o', 's'});

magnitude_colors = {[0.0000, 0.4470, 0.7410], [0.3010, 0.7450, 0.9330]};
phase_colors = {[0.8500, 0.3250, 0.0980], [0.6350, 0.0780, 0.1840]};
phase_target_deg = -90;

%% 1. 读取并统一两种统计文件格式
for i = 1:numel(datasets)
    datasets(i).FullPath = fullfile(script_dir, datasets(i).FileName);
    if ~isfile(datasets(i).FullPath)
        error('找不到输入文件: %s', datasets(i).FullPath);
    end

    raw = load(datasets(i).FullPath);
    required_fields = {'f_mod_use', 'phi_mean'};
    for k = 1:numel(required_fields)
        if ~isfield(raw, required_fields{k})
            error('文件 %s 缺少变量 %s。', ...
                datasets(i).FileName, required_fields{k});
        end
    end

    frequency_Hz = raw.f_mod_use(:);
    phase_deg = raw.phi_mean(:);
    if isfield(raw, 'response_mean')
        response_Hz_per_V = raw.response_mean(:);
        magnitude_source = 'response_mean';
    elseif isfield(raw, 'H_mean')
        response_Hz_per_V = abs(raw.H_mean(:));
        magnitude_source = 'abs(H_mean)';
    elseif isfield(raw, 'D_mean')
        response_Hz_per_V = 1./raw.D_mean(:);
        magnitude_source = '1./D_mean';
    else
        error(['文件 %s 中没有 response_mean、H_mean 或 D_mean，' ...
            '无法获得响应幅值。'], datasets(i).FileName);
    end

    if ~(numel(frequency_Hz) == numel(phase_deg) && ...
            numel(frequency_Hz) == numel(response_Hz_per_V))
        error('文件 %s 中的频率、幅值和相位数组长度不一致。', datasets(i).FileName);
    end

    valid = isfinite(frequency_Hz) & frequency_Hz > 0 & ...
        isfinite(response_Hz_per_V) & response_Hz_per_V > 0 & ...
        isfinite(phase_deg);
    frequency_Hz = frequency_Hz(valid);
    response_Hz_per_V = response_Hz_per_V(valid);
    phase_deg = phase_deg(valid);
    if numel(frequency_Hz) < 2
        error('文件 %s 中有效频点少于 2 个。', datasets(i).FileName);
    end

    [frequency_Hz, order] = sort(frequency_Hz);
    response_Hz_per_V = response_Hz_per_V(order);
    phase_deg = phase_deg(order);

    measured_response = response_Hz_per_V .* exp(1i*deg2rad(phase_deg));
    if datasets(i).ApplyBandpassCompensation
        filter_file = fullfile(analysis_dir, datasets(i).FilterBodeFile);
        if ~isfile(filter_file)
            error('找不到 Pinzhun 带通滤波器 Bode CSV: %s', filter_file);
        end

        [filter_frequency_Hz, filter_response] = ...
            read_bode100_complex_gain(filter_file);
        carrier_Hz = datasets(i).CarrierHz;
        upper_sideband_Hz = carrier_Hz + frequency_Hz;
        lower_sideband_Hz = carrier_Hz - frequency_Hz;
        in_filter_range = upper_sideband_Hz <= max(filter_frequency_Hz) & ...
            lower_sideband_Hz >= min(filter_frequency_Hz);
        if any(~in_filter_range)
            fprintf(2, ['%s: %d 个频点超出滤波器双边带扫描范围，' ...
                '不进行外推并从对比图中排除。\n'], ...
                datasets(i).ShortLabel, nnz(~in_filter_range));
        end

        frequency_Hz = frequency_Hz(in_filter_range);
        measured_response = measured_response(in_filter_range);
        upper_sideband_Hz = upper_sideband_Hz(in_filter_range);
        lower_sideband_Hz = lower_sideband_Hz(in_filter_range);

        response_at_carrier = interp_complex_response( ...
            filter_frequency_Hz, filter_response, carrier_Hz);
        response_at_upper_sideband = interp_complex_response( ...
            filter_frequency_Hz, filter_response, upper_sideband_Hz);
        response_at_lower_sideband = interp_complex_response( ...
            filter_frequency_Hz, filter_response, lower_sideband_Hz);

        % 与 align_phase.m 一致的小相位调制等效复响应。
        relative_upper = response_at_upper_sideband ./ response_at_carrier;
        relative_lower = response_at_lower_sideband ./ response_at_carrier;
        filter_pm_response = 0.5 .* ...
            (relative_upper + conj(relative_lower));
        corrected_response = measured_response ./ filter_pm_response;

        datasets(i).FilterPmMagnitude = abs(filter_pm_response);
        datasets(i).FilterPmPhase_deg = ...
            unwrap(angle(filter_pm_response))*180/pi;
        datasets(i).ExcludedByFilterRange = nnz(~in_filter_range);
        datasets(i).FilterFullPath = filter_file;
    else
        corrected_response = measured_response;
        datasets(i).FilterPmMagnitude = ones(size(frequency_Hz));
        datasets(i).FilterPmPhase_deg = zeros(size(frequency_Hz));
        datasets(i).ExcludedByFilterRange = 0;
        datasets(i).FilterFullPath = '';
    end

    % 由修正后的复响应统一计算幅值和连续相位，消除 ±360°回绕。
    response_Hz_per_V = abs(corrected_response);
    phase_deg = unwrap(angle(corrected_response))*180/pi;

    datasets(i).Frequency_Hz = frequency_Hz;
    datasets(i).Response_Hz_per_V = response_Hz_per_V;
    datasets(i).Phase_deg = phase_deg;
    datasets(i).MagnitudeSource = magnitude_source;
    datasets(i).PhaseMinus90Frequency_Hz = find_phase_crossing_log_frequency( ...
        frequency_Hz, phase_deg, phase_target_deg);

    fprintf('%s: %d 个频点，幅值来自 %s。\n', ...
        datasets(i).ShortLabel, numel(frequency_Hz), magnitude_source);
    if datasets(i).ApplyBandpassCompensation
        fprintf('  已按 align_phase.m 补偿 23 MHz 载波处的带通滤波器复响应。\n');
    end
    if isfinite(datasets(i).PhaseMinus90Frequency_Hz)
        fprintf('  -90° 相位交点 = %.8g Hz (%.6g MHz)\n', ...
            datasets(i).PhaseMinus90Frequency_Hz, ...
            datasets(i).PhaseMinus90Frequency_Hz/1e6);
    else
        fprintf(2, '  当前频率范围内没有检测到 -90° 相位交点。\n');
    end
end

%% 2. 按示例风格绘制双 Y 轴对比图
fig = figure( ...
    'Color', 'w', ...
    'Name', 'Filter-corrected Pinzhun vs. JWS Laser Response', ...
    'Position', [100, 100, 950, 680]);
ax = axes(fig);
hold(ax, 'on');

yyaxis(ax, 'left');
magnitude_handles = gobjects(numel(datasets), 1);
for i = 1:numel(datasets)
    magnitude_handles(i) = plot(ax, ...
        datasets(i).Frequency_Hz/1e6, ...
        datasets(i).Response_Hz_per_V, ...
        'LineStyle', datasets(i).LineStyle, ...
        'Marker', datasets(i).Marker, ...
        'Color', magnitude_colors{i}, ...
        'LineWidth', 1.7, ...
        'MarkerSize', 5, ...
        'MarkerFaceColor', 'w', ...
        'DisplayName', sprintf('%s magnitude', datasets(i).Label));
end
set(ax, 'XScale', 'log', 'YScale', 'log');
ylabel(ax, 'Laser Response (Hz/V)', ...
    'FontWeight', 'bold', 'Color', magnitude_colors{1});
ax.YAxis(1).Color = magnitude_colors{1};

yyaxis(ax, 'right');
phase_handles = gobjects(numel(datasets), 1);
for i = 1:numel(datasets)
    phase_handles(i) = plot(ax, ...
        datasets(i).Frequency_Hz/1e6, ...
        datasets(i).Phase_deg, ...
        'LineStyle', datasets(i).LineStyle, ...
        'Marker', datasets(i).Marker, ...
        'Color', phase_colors{i}, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 4.5, ...
        'MarkerFaceColor', 'w', ...
        'DisplayName', sprintf('%s phase', datasets(i).Label));
end
ylabel(ax, 'Response Phase (deg)', ...
    'FontWeight', 'bold', 'Color', phase_colors{1});
ax.YAxis(2).Color = phase_colors{1};

% 共用 -90°水平参考线，并分别标出两组数据对应的交点频率。
yline(ax, phase_target_deg, ':', '-90 deg', ...
    'Color', [0.35, 0.35, 0.35], ...
    'LineWidth', 1.2, ...
    'LabelHorizontalAlignment', 'left', ...
    'HandleVisibility', 'off');

for i = 1:numel(datasets)
    crossing_Hz = datasets(i).PhaseMinus90Frequency_Hz;
    if ~isfinite(crossing_Hz)
        continue;
    end
    crossing_MHz = crossing_Hz/1e6;
    xline(ax, crossing_MHz, datasets(i).LineStyle, ...
        'Color', phase_colors{i}, ...
        'LineWidth', 1.3, ...
        'HandleVisibility', 'off');
    plot(ax, crossing_MHz, phase_target_deg, 'p', ...
        'Color', phase_colors{i}, ...
        'MarkerFaceColor', phase_colors{i}, ...
        'MarkerSize', 10, ...
        'HandleVisibility', 'off');
end

all_frequency_Hz = vertcat(datasets.Frequency_Hz);
all_phase_deg = vertcat(datasets.Phase_deg);
xlim(ax, [min(all_frequency_Hz), max(all_frequency_Hz)]/1e6);
phase_limits = [floor(min(all_phase_deg)/50)*50, ...
    max(0, ceil(max(all_phase_deg)/50)*50)];
ylim(ax, phase_limits);
phase_span = diff(phase_limits);
for i = 1:numel(datasets)
    crossing_Hz = datasets(i).PhaseMinus90Frequency_Hz;
    if ~isfinite(crossing_Hz)
        continue;
    end
    crossing_MHz = crossing_Hz/1e6;
    label_y = phase_target_deg - (0.045 + 0.055*(i-1))*phase_span;
    text(ax, crossing_MHz*1.035, label_y, ...
        sprintf('%s: %.4g MHz', datasets(i).ShortLabel, crossing_MHz), ...
        'Color', phase_colors{i}, ...
        'FontWeight', 'bold', ...
        'FontSize', 9, ...
        'HorizontalAlignment', 'left', ...
        'VerticalAlignment', 'top');
end

xlabel(ax, 'Modulation Frequency (MHz)', 'FontWeight', 'bold');
title(ax, 'Filter-corrected Pinzhun vs. JWS Laser Driver Response', ...
    'FontSize', 12, 'FontWeight', 'bold');
grid(ax, 'on');
ax.XMinorGrid = 'on';
ax.GridAlpha = 0.22;
ax.MinorGridAlpha = 0.10;
ax.FontName = 'Arial';
ax.FontSize = 10;
ax.TickDir = 'in';
box(ax, 'on');
legend(ax, [magnitude_handles; phase_handles], ...
    'Location', 'southwest', 'NumColumns', 2);

%% 3. 保存图片、可编辑 FIG 和 -90°交点汇总
time_str = char(datetime('now', 'Format', 'yyyyMMdd_HHmmss'));
png_file = fullfile(script_dir, sprintf( ...
    'Laser_Response_Comparison_Pinzhun_FilterCorrected_vs_JWS_%s.png', time_str));
fig_file = fullfile(script_dir, sprintf( ...
    'Laser_Response_Comparison_Pinzhun_FilterCorrected_vs_JWS_%s.fig', time_str));
csv_file = fullfile(script_dir, sprintf( ...
    'Laser_Response_Comparison_Pinzhun_FilterCorrected_vs_JWS_%s.csv', time_str));
mat_file = fullfile(script_dir, sprintf( ...
    'Laser_Response_Comparison_Pinzhun_FilterCorrected_vs_JWS_%s.mat', time_str));

exportgraphics(fig, png_file, 'Resolution', 300);
savefig(fig, fig_file);

ComparisonTable = table( ...
    string({datasets.ShortLabel})', ...
    string({datasets.FileName})', ...
    logical([datasets.ApplyBandpassCompensation])', ...
    [datasets.CarrierHz]', ...
    [datasets.ExcludedByFilterRange]', ...
    [datasets.PhaseMinus90Frequency_Hz]', ...
    [datasets.PhaseMinus90Frequency_Hz]'/1e6, ...
    'VariableNames', { ...
        'Dataset', 'SourceFile', 'BandpassCompensated', ...
        'Carrier_Hz', 'ExcludedByFilterRange', ...
        'PhaseMinus90Frequency_Hz', 'PhaseMinus90Frequency_MHz'});
writetable(ComparisonTable, csv_file);
save(mat_file, 'datasets', 'ComparisonTable', 'phase_target_deg');

disp(ComparisonTable);
fprintf('对比图片: %s\n', png_file);
fprintf('可编辑图: %s\n', fig_file);
fprintf('交点汇总: %s\n', csv_file);
fprintf('修正数据: %s\n', mat_file);

%% 局部函数
function crossing_frequency_Hz = find_phase_crossing_log_frequency( ...
        frequency_Hz, phase_deg, target_phase_deg)
%FIND_PHASE_CROSSING_LOG_FREQUENCY 在 log10(f) 上线性插值相位交点。
% 若存在多个交点，返回最低频率的交点。

    crossing_frequency_Hz = NaN;
    phase_offset = phase_deg - target_phase_deg;

    exact_index = find(abs(phase_offset) < 1e-9, 1, 'first');
    if ~isempty(exact_index)
        crossing_frequency_Hz = frequency_Hz(exact_index);
        return;
    end

    crossing_index = find( ...
        phase_offset(1:end-1).*phase_offset(2:end) < 0, 1, 'first');
    if isempty(crossing_index)
        return;
    end

    f1 = frequency_Hz(crossing_index);
    f2 = frequency_Hz(crossing_index + 1);
    phase1 = phase_deg(crossing_index);
    phase2 = phase_deg(crossing_index + 1);
    log_crossing_frequency = log10(f1) + ...
        (target_phase_deg - phase1) * (log10(f2) - log10(f1)) / ...
        (phase2 - phase1);
    crossing_frequency_Hz = 10^log_crossing_frequency;
end
