# 通用激光器频率响应分析模块

本模块处理双通道 PicoScope MAT 数据：A 通道为光学拍频，B 通道为正弦
注入参考。程序逐文件估计拍频载波，完成复数解调和相干拟合，输出激光器
响应幅值、连续相位、−90°相位交点以及数据质量标记。

## 软件要求

- MATLAB R2021b 或更高版本。
- Signal Processing Toolbox（使用 `butter`、`filter` 和 `hilbert`）。
- 建议 Windows 10/11，内存不少于原始最大 MAT 文件的 2 倍。

## 输入要求

每个 MAT 文件必须包含 `A`、`B` 和 `Tinterval`。文件名必须包含调制频率，
支持 `Hz`、`kHz` 和 `MHz`，例如 `A_beat_B_sin_300kHz.mat`。

## 快速使用

将整个模块文件夹发给使用者并解压。在 MATLAB 中进入模块目录，然后运行：

```matlab
result = analyze_laser_response('D:\LaserData');
```

如果文件名不是默认形式，使用配置：

```matlab
options = struct( ...
    'FilePattern', 'measurement_*Hz.mat', ...
    'CarrierHintHz', 20e6, ...
    'DigitalModAmp', 0, ...
    'ResponsePolarity', +1, ...
    'PhaseAmbiguity180', true);
result = analyze_laser_response('D:\LaserData', options);
```

也可直接运行 `example_basic.m`。目录中同时有旧数据和 `_new` 重测数据时，
参考 `example_hybrid_retest.m`。

返回值中，`result.per_file` 是逐文件结果表，`result.frequency_summary` 是频点
汇总表，`result.minus90_frequency_Hz` 是 −90°相位交点，`result.output_paths`
集中保存全部输出文件路径。旧字段名仍保留，已有脚本无需修改。

## 关键参数

- `DigitalModAmp = 0`：使用 B 通道实测幅值，响应单位为 Hz/V。
- `ResponsePolarity`：执行器极性。低频相位应在 0°附近时通常取 `+1`；
  若接线定义使响应整体反向则取 `-1`。
- `PhaseAmbiguity180 = true`：适合拍频方向可能翻转的测量，用模 180°方式
  选择连续相位分支。
- `CarrierHintHz`：只用于记录载波偏差，实际载波仍逐文件估计。
- `FileList`：显式文件列表，优先于 `FilePattern`，适合混合新旧数据。

## 输出

默认在数据目录的 `processed_results` 中生成：

- `Laser_Response_*.png`：汇总幅相响应和 −90°交点。
- `PDH_Batch_Result_*.csv`：逐文件明细。
- `PDH_Frequency_Summary_*.csv`：按频率聚合结果。
- `PDH_Statistics_*.mat`：完整 MATLAB 结果。
- `per_file`：每个原始文件的文本报告和两张诊断图。

## 质量标记

- `OK`：当前阈值下可用。
- `MARGINAL_PHASE_SNR`：相位相干 SNR 为 0–10 dB，建议复测。
- `LOW_PHASE_SNR`：相位相干 SNR 小于 0 dB，不建议用于拟合带宽。
- `LOW_INPUT_SNR`：注入参考信号不足。
- `CHECK_MAGNITUDE_OUTLIER`：幅值相对相邻频点偏差超过默认 12 dB，需要
  检查是否为真实共振/凹陷或单次测量异常。

程序不会自动删除、插值或平滑低质量点。确认测试链路中使用了外部滤波器
时，应另行提供滤波器复响应数据进行修正，不能只做固定相位平移。
