function [D_coeff, phase_diff_deg, f_mod_est, diagnostics] = ...
    process_pdh_data_adaptive(filename, f_carrier_hint, digital_mod_amp)
%PROCESS_PDH_DATA_ADAPTIVE Extract laser frequency response from PicoScope data.
%
% This implementation does not assume that the optical beat carrier is fixed
% from one record to the next.  It estimates the mean carrier from positive
% zero crossings, performs complex heterodyne demodulation at that carrier,
% and uses a coherent least-squares fit at the commanded modulation
% frequency.  The processing is chunked so that long, low-frequency records
% do not require additional full-length working arrays.
%
% Outputs:
%   D_coeff          input amplitude / frequency-deviation amplitude
%                    (V/Hz when digital_mod_amp == 0, otherwise LSB/Hz)
%   phase_diff_deg   phase of frequency response relative to channel B
%   f_mod_est        modulation frequency parsed from the file name
%   diagnostics      structure containing carrier, complex response and SNR

    if nargin < 2
        f_carrier_hint = [];
    end
    if nargin < 3 || isempty(digital_mod_amp)
        digital_mod_amp = 0;
    end

    [sigA, sigB, fs, filename] = load_pico_data_dual(1, filename);
    sigA = double(sigA(:));
    sigB = double(sigB(:));
    if isempty(sigA) || isempty(sigB)
        error('Input file contains no usable samples: %s', filename);
    end

    f_mod_est = parse_modulation_frequency(filename);
    if f_mod_est >= fs/2
        error('Modulation frequency %.6g Hz is above Nyquist %.6g Hz.', ...
            f_mod_est, fs/2);
    end

    [f_carrier_est, crossing_count] = estimate_carrier_zero_crossings(sigA, fs);
    if ~isempty(f_carrier_hint) && isfinite(f_carrier_hint) && f_carrier_hint > 0
        carrier_offset = f_carrier_est - f_carrier_hint;
    else
        carrier_offset = NaN;
    end

    % After real-to-complex mixing, the unwanted image is located at the
    % aliased frequency corresponding to 2*f_carrier.  Keep a conservative
    % margin from that image while retaining the FM sidebands.
    n = numel(sigA);
    image_distance = abs(mod(2*f_carrier_est + fs/2, fs) - fs/2);
    requested_cutoff = max(8e6, 1.5*f_mod_est);
    lp_cutoff = min(requested_cutoff, 0.35*image_distance);
    use_analytic_phase = lp_cutoff <= 1.1*f_mod_est;
    max_analytic_samples = 5000000;
    if use_analytic_phase && n > max_analytic_samples
        error(['Insufficient image-free demodulation bandwidth: carrier %.6f MHz, ' ...
            'modulation %.6f MHz, available cutoff %.6f MHz; the record is ' ...
            'too long for the analytic-signal fallback.'], ...
            f_carrier_est/1e6, f_mod_est/1e6, lp_cutoff/1e6);
    end
    if use_analytic_phase
        b_lp = 1;
        a_lp = 1;
        lp_cutoff = NaN;
        demodulation_method = 'analytic-signal-phase';
    else
        lp_cutoff = min(lp_cutoff, 0.45*fs);
        [b_lp, a_lp] = butter(4, lp_cutoff/(fs/2), 'low');
        demodulation_method = 'chunked-complex-heterodyne';
    end

    duration = (n-1)/fs;
    time_mid = duration/2;
    time_scale = max(duration/2, 1/fs);
    phase_step = 2*pi*f_carrier_est/fs;
    chunk_size = 1000000;

    normal_matrix = zeros(4, 4);
    rhs_phase = zeros(4, 1);
    rhs_B = zeros(4, 1);
    phase_energy = 0;
    B_energy = 0;
    valid_count = 0;

    if use_analytic_phase
        edge_samples = min(floor(0.05*n), ...
            max(100, ceil(5*fs/f_mod_est)));
        kept_index = ((edge_samples + 1):(n - edge_samples))';
        analytic_signal = hilbert(sigA - mean(sigA));
        phase_values = unwrap(angle(analytic_signal(kept_index)));
        t = double(kept_index - 1)/fs;
        t_centered = (t - time_mid)/time_scale;
        tone_angle = 2*pi*f_mod_est*t;
        X = [ones(numel(t),1), t_centered, cos(tone_angle), sin(tone_angle)];
        B_values = sigB(kept_index);
        normal_matrix = X'*X;
        rhs_phase = X'*phase_values;
        rhs_B = X'*B_values;
        phase_energy = phase_values'*phase_values;
        B_energy = B_values'*B_values;
        valid_count = numel(t);
    else
        zi_I = zeros(max(numel(a_lp), numel(b_lp))-1, 1);
        zi_Q = zi_I;
        previous_phase = NaN;
        settle_samples = max(100, ceil(12*fs/(2*pi*lp_cutoff)));

        for first = 1:chunk_size:n
            last = min(first + chunk_size - 1, n);
            global_index = (first:last)';
            theta = phase_step * double(global_index - 1);
            x = sigA(first:last);

            mixed_I = 2*x.*cos(theta);
            mixed_Q = -2*x.*sin(theta);
            [base_I, zi_I] = filter(b_lp, a_lp, mixed_I, zi_I);
            [base_Q, zi_Q] = filter(b_lp, a_lp, mixed_Q, zi_Q);

            phase_chunk = unwrap(angle(complex(base_I, base_Q)));
            if isfinite(previous_phase)
                phase_chunk = phase_chunk + ...
                    2*pi*round((previous_phase - phase_chunk(1))/(2*pi));
            end
            previous_phase = phase_chunk(end);

            keep = global_index > settle_samples;
            if ~any(keep)
                continue;
            end

            kept_index = global_index(keep);
            t = double(kept_index - 1)/fs;
            t_centered = (t - time_mid)/time_scale;
            tone_angle = 2*pi*f_mod_est*t;
            X = [ones(numel(t),1), t_centered, cos(tone_angle), sin(tone_angle)];
            phase_values = phase_chunk(keep);
            B_values = sigB(kept_index);

            normal_matrix = normal_matrix + X'*X;
            rhs_phase = rhs_phase + X'*phase_values;
            rhs_B = rhs_B + X'*B_values;
            phase_energy = phase_energy + phase_values'*phase_values;
            B_energy = B_energy + B_values'*B_values;
            valid_count = valid_count + numel(t);
        end
    end

    if valid_count < 100 || rcond(normal_matrix) < 1e-13
        error('Coherent fit is ill-conditioned or contains too few valid samples.');
    end

    beta_phase = normal_matrix\rhs_phase;
    beta_B = normal_matrix\rhs_B;
    if use_analytic_phase
        f_carrier_est = beta_phase(2)/(2*pi*time_scale);
        if ~isempty(f_carrier_hint) && isfinite(f_carrier_hint) && ...
                f_carrier_hint > 0
            carrier_offset = f_carrier_est - f_carrier_hint;
        end
    end
    phase_phasor_filtered = beta_phase(3) - 1i*beta_phase(4);
    B_phasor = beta_B(3) - 1i*beta_B(4);

    % Compensate the known causal demodulation-filter response at f_mod.
    if use_analytic_phase
        H_lp_at_fmod = 1;
    else
        omega_mod = 2*pi*f_mod_est/fs;
        numerator = sum(b_lp(:).*exp(-1i*omega_mod*(0:numel(b_lp)-1)'));
        denominator = sum(a_lp(:).*exp(-1i*omega_mod*(0:numel(a_lp)-1)'));
        H_lp_at_fmod = numerator/denominator;
    end
    phase_phasor = phase_phasor_filtered/H_lp_at_fmod;
    if abs(B_phasor) <= 100*eps(max(abs(sigB)))
        error('Channel B has no resolvable tone at %.6g Hz.', f_mod_est);
    end

    if digital_mod_amp == 0
        input_phasor = B_phasor;
        input_unit = 'V';
    else
        input_phasor = digital_mod_amp * B_phasor/abs(B_phasor);
        input_unit = 'LSB';
    end

    % d(phi)/dt/(2*pi) converts beat phase to frequency deviation.
    frequency_phasor = 1i*f_mod_est*phase_phasor;
    response_phasor = frequency_phasor/input_phasor;
    response_magnitude = abs(response_phasor);
    if ~(isfinite(response_magnitude) && response_magnitude > 0)
        error('Extracted response is non-finite or zero.');
    end

    D_coeff = 1/response_magnitude;
    phase_diff_deg = angle(response_phasor)*180/pi;

    if use_analytic_phase
        phase_residual = phase_values - X*beta_phase;
        B_residual = B_values - X*beta_B;
        phase_sse = phase_residual'*phase_residual;
        B_sse = B_residual'*B_residual;
    else
        phase_sse = max(0, phase_energy - beta_phase'*rhs_phase);
        B_sse = max(0, B_energy - beta_B'*rhs_B);
    end
    phase_noise_variance = phase_sse/max(valid_count-4, 1);
    B_noise_variance = B_sse/max(valid_count-4, 1);
    phase_fit_ratio_dB = 10*log10(max(abs(phase_phasor_filtered)^2/2, realmin) / ...
        max(phase_noise_variance, realmin));
    B_fit_ratio_dB = 10*log10(max(abs(B_phasor)^2/2, realmin) / ...
        max(B_noise_variance, realmin));
    phase_coherent_snr_dB = phase_fit_ratio_dB + ...
        10*log10(max(valid_count/2, 1));
    B_coherent_snr_dB = B_fit_ratio_dB + ...
        10*log10(max(valid_count/2, 1));

    diagnostics = struct();
    diagnostics.filename = filename;
    diagnostics.fs_Hz = fs;
    diagnostics.sample_count = n;
    diagnostics.duration_s = duration;
    diagnostics.f_carrier_est_Hz = f_carrier_est;
    diagnostics.f_carrier_hint_Hz = f_carrier_hint;
    diagnostics.carrier_offset_Hz = carrier_offset;
    diagnostics.carrier_crossing_count = crossing_count;
    diagnostics.demod_lowpass_Hz = lp_cutoff;
    diagnostics.demodulation_method = demodulation_method;
    diagnostics.phase_modulation_phasor_rad = phase_phasor;
    diagnostics.phase_modulation_amplitude_rad = abs(phase_phasor);
    diagnostics.input_phasor = input_phasor;
    diagnostics.input_amplitude = abs(input_phasor);
    diagnostics.input_unit = input_unit;
    diagnostics.frequency_deviation_phasor_Hz = frequency_phasor;
    diagnostics.frequency_deviation_amplitude_Hz = abs(frequency_phasor);
    diagnostics.response_phasor = response_phasor;
    diagnostics.response_magnitude = response_magnitude;
    diagnostics.response_unit = sprintf('Hz/%s', input_unit);
    diagnostics.phase_tone_to_residual_dB = phase_fit_ratio_dB;
    diagnostics.input_tone_to_residual_dB = B_fit_ratio_dB;
    diagnostics.phase_coherent_snr_dB = phase_coherent_snr_dB;
    diagnostics.input_coherent_snr_dB = B_coherent_snr_dB;

    fprintf(['Adaptive response: f_mod %.6g Hz, carrier %.6f MHz, ' ...
        'input %.6g %s, response %.6g %s, phase %.3f deg, fit ratio %.1f dB\n'], ...
        f_mod_est, f_carrier_est/1e6, abs(input_phasor), input_unit, ...
        response_magnitude, diagnostics.response_unit, phase_diff_deg, ...
        phase_fit_ratio_dB);
end

function f_mod = parse_modulation_frequency(filename)
    tokens = regexp(filename, '([0-9]*\.?[0-9]+)\s*(k|m)?hz', ...
        'tokens', 'once', 'ignorecase');
    if isempty(tokens)
        error('Cannot parse modulation frequency from file name: %s', filename);
    end
    f_mod = str2double(tokens{1});
    unit = lower(tokens{2});
    if strcmp(unit, 'k')
        f_mod = f_mod*1e3;
    elseif strcmp(unit, 'm')
        f_mod = f_mod*1e6;
    end
    if ~(isfinite(f_mod) && f_mod > 0)
        error('Parsed modulation frequency is invalid: %s', filename);
    end
end

function [f_carrier, crossing_count] = estimate_carrier_zero_crossings(signal, fs)
    signal = signal - mean(signal);
    n = numel(signal);
    chunk_size = 2000000;
    crossing_count = 0;
    first_time = NaN;
    last_time = NaN;

    first = 1;
    while first < n
        last = min(first + chunk_size - 1, n-1);
        x0 = signal(first:last);
        x1 = signal(first+1:last+1);
        local_index = find(x0 <= 0 & x1 > 0);
        if ~isempty(local_index)
            denominator = x1(local_index) - x0(local_index);
            fraction = -x0(local_index)./denominator;
            global_left_index = double(first - 1 + local_index);
            crossing_times = (global_left_index - 1 + fraction)/fs;
            if ~isfinite(first_time)
                first_time = crossing_times(1);
            end
            last_time = crossing_times(end);
            crossing_count = crossing_count + numel(crossing_times);
        end
        first = last + 1;
    end

    if crossing_count < 10 || ~(last_time > first_time)
        error('Unable to estimate a reliable carrier from channel A.');
    end
    f_carrier = (crossing_count - 1)/(last_time - first_time);
    if ~(isfinite(f_carrier) && f_carrier > 0 && f_carrier < fs/2)
        error('Estimated carrier %.6g Hz is outside the sampled band.', f_carrier);
    end
end
