function [output_dir, ManifestTable] = export_laser_per_file_results( ...
        ResultTable, SummaryTable, save_filepath)
%EXPORT_LASER_PER_FILE_RESULTS Export TXT and two PNGs for every input MAT.
%
% The output naming follows the historical laser-response processing:
%   *_result.txt
%   *_origin_result.png
%   *_calc_frequency.png
%
% The adaptive processor does not retain full demodulated waveforms in
% memory.  The figures therefore show the fitted response phasor, fit
% quality, and reconstructed injection/frequency-deviation waveforms.

    output_dir = fullfile(save_filepath, 'per_file');
    if ~isfolder(output_dir)
        mkdir(output_dir);
    end

    row_count = height(ResultTable);
    result_txt = strings(row_count, 1);
    origin_png = strings(row_count, 1);
    calculation_png = strings(row_count, 1);
    aligned_phase_deg = nan(row_count, 1);

    for ii = 1:row_count
        if ~ResultTable.Valid(ii)
            continue;
        end

        frequency = ResultTable.F_mod_Hz(ii);
        summary_index = find_frequency_row( ...
            SummaryTable.F_mod_Hz, frequency);
        if isempty(summary_index)
            warning('没有找到 %.9g Hz 的汇总相位，跳过逐文件输出。', ...
                frequency);
            continue;
        end
        phase_deg = SummaryTable.Phase_mean_deg(summary_index);
        aligned_phase_deg(ii) = phase_deg;

        source_file = char(ResultTable.FileName{ii});
        [~, base_name] = fileparts(source_file);
        txt_file = fullfile(output_dir, [base_name, '_result.txt']);
        origin_file = fullfile(output_dir, ...
            [base_name, '_origin_result.png']);
        calculation_file = fullfile(output_dir, ...
            [base_name, '_calc_frequency.png']);

        write_result_report(txt_file, source_file, ResultTable(ii,:), ...
            phase_deg);
        create_origin_diagnostic(origin_file, base_name, ...
            ResultTable(ii,:), phase_deg);
        create_frequency_diagnostic(calculation_file, base_name, ...
            ResultTable(ii,:), phase_deg);

        result_txt(ii) = string(txt_file);
        origin_png(ii) = string(origin_file);
        calculation_png(ii) = string(calculation_file);
        fprintf('逐文件输出 [%d/%d]: %s\n', ii, row_count, base_name);
    end

    ManifestTable = table(string(ResultTable.FileName), ResultTable.Valid, ...
        ResultTable.F_mod_Hz, aligned_phase_deg, result_txt, origin_png, ...
        calculation_png, 'VariableNames', {'SourceFile', 'Valid', ...
        'F_mod_Hz', 'Phase_Aligned_deg', 'ResultTxt', ...
        'OriginDiagnosticPng', 'FrequencyDiagnosticPng'});
    manifest_file = fullfile(output_dir, 'Per_File_Output_Manifest.csv');
    writetable(ManifestTable, manifest_file);
end

function index = find_frequency_row(frequency_list, target_frequency)
    tolerance = max(1e-9, 1e-9*abs(target_frequency));
    index = find(abs(frequency_list - target_frequency) <= tolerance, ...
        1, 'first');
end

function write_result_report(output_file, source_file, row, phase_deg)
    fid = fopen(output_file, 'w', 'n', 'UTF-8');
    if fid < 0
        error('无法创建逐文件结果报告: %s', output_file);
    end
    file_cleanup = onCleanup(@() fclose(fid));

    delta_nu_amp = row.Response_Hz_per_Input*row.Input_Amplitude;
    delta_phi_amp = delta_nu_amp/row.F_mod_Hz;
    [~, source_name, source_extension] = fileparts(source_file);

    fprintf(fid, '======================================================\n');
    fprintf(fid, '           全数字 PDH 鉴频参数自动解算报告\n');
    fprintf(fid, '======================================================\n');
    fprintf(fid, '原始数据源: %s%s\n', source_name, source_extension);
    fprintf(fid, '解算时间  : %s\n\n', ...
        char(datetime('now', 'Format', 'yyyy-MM-dd HH:mm:ss')));
    fprintf(fid, '【1. 注入与边界条件】\n');
    fprintf(fid, '- 闭环调制频率 f_mod  : %.3f Hz\n', row.F_mod_Hz);
    fprintf(fid, '- 使用 B 通道实际信号幅值计算\n');
    fprintf(fid, '- B 通道注入幅值      : %.6g %s\n', ...
        row.Input_Amplitude, char(row.Input_Unit));
    fprintf(fid, '- 逐文件估计拍频载波  : %.6f MHz\n', ...
        row.Carrier_Hz/1e6);
    fprintf(fid, '- 自适应解调方法      : %s\n\n', ...
        char(row.Demodulation_Method));
    fprintf(fid, '【2. 稳态区提取特征】\n');
    fprintf(fid, '- 光学拍频相位幅值 Δφ : %.6f rad\n', delta_phi_amp);
    fprintf(fid, '- 等效物理频率偏移 Δν : %.6f Hz\n', delta_nu_amp);
    fprintf(fid, '- 相位相干拟合 SNR    : %.3f dB\n', ...
        row.Phase_Coherent_SNR_dB);
    fprintf(fid, '- 注入相干拟合 SNR    : %.3f dB\n\n', ...
        row.Input_Coherent_SNR_dB);
    fprintf(fid, '【3. 核心标定结果】\n');
    fprintf(fid, '=> 激光器逆响应系数 D : %.6e %s/Hz\n', ...
        row.D_coeff_Input_per_Hz, char(row.Input_Unit));
    fprintf(fid, '=> 激光器频率响应     : %.6e Hz/%s\n', ...
        row.Response_Hz_per_Input, char(row.Input_Unit));
    fprintf(fid, '=> 连续修正后响应相位 : %.2f °\n', phase_deg);
    fprintf(fid, '=> 原始单文件相位     : %.2f °\n', row.Phase_Diff_deg);
    if ismember('Local_Magnitude_Deviation_dB', ...
            row.Properties.VariableNames)
        if isfinite(row.Local_Magnitude_Deviation_dB)
            fprintf(fid, '=> 相邻频点幅值偏差   : %.2f dB\n', ...
                row.Local_Magnitude_Deviation_dB);
        else
            fprintf(fid, '=> 相邻频点幅值偏差   : N/A（频率边界）\n');
        end
    end
    fprintf(fid, '=> 结果质量标记       : %s\n', char(row.Quality_Flag));
    fprintf(fid, '======================================================\n');
    clear file_cleanup;
end

function create_origin_diagnostic(output_file, base_name, row, phase_deg)
    frequency = row.F_mod_Hz;
    cycle = linspace(0, 4, 1600)';
    time = cycle/frequency;
    delta_nu_amp = row.Response_Hz_per_Input*row.Input_Amplitude;
    delta_phi_amp = delta_nu_amp/frequency;
    phase_waveform = delta_phi_amp*cos(2*pi*cycle + ...
        (phase_deg - 90)*pi/180);
    phase_trend = zeros(size(phase_waveform));
    input_waveform = row.Input_Amplitude*cos(2*pi*cycle);

    fig = figure('Visible', 'off', 'Color', 'w', ...
        'Position', [100, 100, 1000, 700]);
    figure_cleanup = onCleanup(@() close(fig));
    subplot(2, 1, 1);
    plot(time, phase_waveform, 'Color', [0.65, 0.65, 0.65], ...
        'LineWidth', 1.2, 'DisplayName', '相干拟合重构相位');
    hold on;
    plot(time, phase_trend, 'r--', 'LineWidth', 1.5, ...
        'DisplayName', '去漂移趋势基线');
    title(sprintf('A 通道解调相位与趋势 (调制频率: %.2f Hz)', ...
        frequency));
    ylabel('Phase (rad)');
    legend('Location', 'best');
    grid on;

    subplot(2, 1, 2);
    yyaxis left;
    plot(time, phase_waveform, 'b', 'LineWidth', 1.5, ...
        'DisplayName', '去漂移基带相位');
    ylabel('Detrended Phase (rad)');
    ax = gca;
    ax.YColor = 'b';
    hold on;
    yyaxis right;
    plot(time, input_waveform, 'Color', '#D95319', ...
        'LineWidth', 1.4, 'DisplayName', 'B 通道驱动波形');
    ylabel(sprintf('Waveform B (%s)', char(row.Input_Unit)));
    ax = gca;
    ax.YColor = '#D95319';
    xlabel('Time (s)');
    legend('Location', 'best');
    grid on;
    title(sprintf(['自适应去漂移相位与驱动波形关联对比 | ' ...
        'SNR %.1f dB | %s'], row.Phase_Coherent_SNR_dB, ...
        char(row.Quality_Flag)), 'Interpreter', 'none');

    sgtitle(strrep(base_name, '_', '\_'), ...
        'Interpreter', 'tex', 'FontWeight', 'bold');
    exportgraphics(fig, output_file, 'Resolution', 300);
    clear figure_cleanup;
end

function create_frequency_diagnostic(output_file, base_name, row, phase_deg)
    frequency = row.F_mod_Hz;
    cycle = linspace(0, 8, 2400)';
    time = cycle/frequency;
    input_waveform = row.Input_Amplitude*cos(2*pi*cycle);
    frequency_deviation_amplitude = ...
        row.Response_Hz_per_Input*row.Input_Amplitude;
    frequency_waveform = frequency_deviation_amplitude* ...
        cos(2*pi*cycle + phase_deg*pi/180);
    analytic_frequency_waveform = frequency_waveform;

    fig = figure('Visible', 'off', 'Color', 'w', ...
        'Position', [100, 100, 1000, 700]);
    figure_cleanup = onCleanup(@() close(fig));
    subplot(2, 1, 1);
    first_half = cycle <= 4;
    plot(time(first_half), analytic_frequency_waveform(first_half), ...
        'Color', [0.50, 0.45, 1.00], 'LineWidth', 4, ...
        'DisplayName', '解析映射理想频率');
    hold on;
    plot(time(first_half), frequency_waveform(first_half), 'r--', ...
        'LineWidth', 1.2, 'DisplayName', '相干拟合重构频率');
    xlabel('Time (s)');
    ylabel('Frequency Deviation (Hz)');
    title(sprintf('频率解算对比 (f_{mod} = %.2f Hz)', frequency));
    legend('Location', 'best');
    grid on;

    subplot(2, 1, 2);
    yyaxis left;
    plot(time, frequency_waveform, 'LineWidth', 1.8, ...
        'Color', '#0072BD');
    ylabel('Fitted frequency deviation (Hz)');
    yyaxis right;
    plot(time, input_waveform, 'LineWidth', 1.5, ...
        'Color', '#D95319');
    ylabel(sprintf('Fitted injection (%s)', char(row.Input_Unit)));
    xlabel('Time (s)');
    grid on;
    title(sprintf(['物理频率偏差与注入信号相位对比 ' ...
        '(计算相位差: %.2f° | %s)'], phase_deg, ...
        char(row.Quality_Flag)), 'Interpreter', 'none');
    legend({'Laser frequency deviation', 'Injected signal'}, ...
        'Location', 'best');
    sgtitle(strrep(base_name, '_', '\_'), ...
        'Interpreter', 'tex', 'FontWeight', 'bold');
    exportgraphics(fig, output_file, 'Resolution', 300);
    clear figure_cleanup;
end
