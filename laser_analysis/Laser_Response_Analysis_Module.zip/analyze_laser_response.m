function result = analyze_laser_response(data_path, options)
%ANALYZE_LASER_RESPONSE 通用激光器调制响应批处理入口。
%
% result = analyze_laser_response(data_path)
% result = analyze_laser_response(data_path, options)
%
% 输入数据必须是 MAT 文件，并包含 A、B 和 Tinterval：
%   A         光学拍频波形
%   B         注入参考波形
%   Tinterval 相邻采样点时间间隔，单位 s
%
% 文件名必须包含调制频率，例如：
%   A_beat_B_sin_100Hz.mat
%   A_beat_B_sin_20kHz.mat
%   A_beat_B_sin_3MHz.mat
%
% 常用 options 字段：
%   FilePattern                文件通配符
%   FileList                   显式文件列表；设置后优先于 FilePattern
%   OutputPath                 输出目录
%   OutputTag                  输出文件标签
%   FigureTitle                汇总图标题
%   ExpectedFileCount          预期文件数；0 表示不检查
%   CarrierHintHz              拍频参考值，仅用于记录偏差
%   DigitalModAmp              0 使用 B 通道实测幅值
%   ResponsePolarity           +1 或 -1，执行器极性
%   PhaseAmbiguity180          是否按模 180 度连续展开
%   PhaseTargetDeg             相位交点，默认 -90 度
%   MagnitudeOutlierThresholddB 局部幅值异常阈值，默认 12 dB

    if nargin < 1 || isempty(data_path)
        if usejava('desktop')
            data_path = uigetdir(pwd, '选择激光器响应 MAT 数据目录');
            if isequal(data_path, 0)
                error('未选择数据目录。');
            end
        else
            error('必须指定 data_path。');
        end
    end
    if nargin < 2 || isempty(options)
        options = struct();
    end
    if ~(isstruct(options) && isscalar(options))
        error('options 必须是标量结构体。');
    end
    if ~isfolder(data_path)
        error('数据目录不存在: %s', data_path);
    end

    module_dir = fileparts(mfilename('fullpath'));
    addpath(module_dir);
    laser_response_config = options;
    laser_response_config.DataPath = char(data_path); %#ok<STRNU>

    run(fullfile(module_dir, 'process_laser_response_batch.m'));

    result = struct();
    result.ResultTable = ResultTable;
    result.SummaryTable = SummaryTable;
    result.phase_minus90_frequency_Hz = phase_minus90_frequency_Hz;
    % 便于脚本化使用的语义化别名；保留上方字段以兼容原有代码。
    result.per_file = ResultTable;
    result.frequency_summary = SummaryTable;
    result.minus90_frequency_Hz = phase_minus90_frequency_Hz;
    result.detail_csv = detail_csv;
    result.summary_csv = summary_csv;
    result.statistics_mat = mat_file;
    result.figure_file = figure_file;
    result.per_file_output_dir = per_file_output_dir;
    result.output_paths = struct( ...
        'detail_csv', detail_csv, ...
        'summary_csv', summary_csv, ...
        'statistics_mat', mat_file, ...
        'figure_file', figure_file, ...
        'per_file_output_dir', per_file_output_dir);
end
