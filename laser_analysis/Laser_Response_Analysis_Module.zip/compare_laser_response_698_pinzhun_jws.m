%% 698 nm Pinzhun 与 JWS 激光器响应对比（不做滤波器补偿）
% 将本脚本与两份PDH_Statistics_*.mat放在同一目录后直接运行。
% 本脚本只使用MAT中已经保存的响应，不读取滤波器Bode数据，也不调用align_phase。

clear; close all; clc;

script_path = mfilename('fullpath');
script_dir = fileparts(script_path);
if isempty(script_dir)
    script_dir = pwd;
end

datasets = struct( ...
    'Label', {'Pinzhun 698', 'JWS 698'}, ...
    'ShortLabel', {'Pinzhun', 'JWS'}, ...
    'FileName', { ...
        'PDH_Statistics_laser_698_pinzhun_20260731_181421.mat', ...
        'PDH_Statistics_jws_698_jws_20260805_hybrid_20260805_165432.mat'}, ...
    'LineStyle', {'-', '--'}, ...
    'Marker', {'o', 's'});

magnitude_colors = {[0.0000, 0.4470, 0.7410], [0.3010, 0.7450, 0.9330]};
phase_colors = {[0.8500, 0.3250, 0.0980], [0.6350, 0.0780, 0.1840]};
phase_target_deg = -90;

%% 1. 读取两份已经处理完成的激光器响应
for i = 1:numel(datasets)
    datasets(i).FullPath = fullfile(script_dir, datasets(i).FileName);
    if ~isfile(datasets(i).FullPath)
        error('找不到输入文件: %s', datasets(i).FullPath);
    end

    raw = load(datasets(i).FullPath);
    required_fields = {'f_mod_use', 'phi_mean'};
    for k = 1:numel(required_fields)
        if ~isfield(raw, required_fields{k})
            error('文件%s缺少变量%s。', ...
                datasets(i).FileName, required_fields{k});
        end
    end

    frequency_Hz = double(raw.f_mod_use(:));
    phase_deg = double(raw.phi_mean(:));
    if isfield(raw, 'response_mean')
        response_Hz_per_V = double(raw.response_mean(:));
        magnitude_source = 'response_mean';
    elseif isfield(raw, 'H_mean')
        response_Hz_per_V = abs(double(raw.H_mean(:)));
        magnitude_source = 'abs(H_mean)';
    elseif isfield(raw, 'D_mean')
        response_Hz_per_V = 1./double(raw.D_mean(:));
        magnitude_source = '1./D_mean';
    else
        error('文件%s中没有可用的响应幅值变量。', datasets(i).FileName);
    end

    if ~(numel(frequency_Hz) == numel(phase_deg) && ...
            numel(frequency_Hz) == numel(response_Hz_per_V))
        error('文件%s中的频率、幅值和相位数组长度不一致。', datasets(i).FileName);
    end

    valid = isfinite(frequency_Hz) & frequency_Hz > 0 & ...
        isfinite(response_Hz_per_V) & response_Hz_per_V > 0 & ...
        isfinite(phase_deg);
    frequency_Hz = frequency_Hz(valid);
    response_Hz_per_V = response_Hz_per_V(valid);
    phase_deg = phase_deg(valid);
    if numel(frequency_Hz) < 2
        error('文件%s中的有效频点少于2个。', datasets(i).FileName);
    end

    [frequency_Hz, order] = sort(frequency_Hz);
    response_Hz_per_V = response_Hz_per_V(order);
    phase_deg = phase_deg(order);

    % 这里只消除±360°数值回绕，不施加任何滤波器相位修正。
    phase_deg = unwrap(phase_deg*pi/180)*180/pi;

    datasets(i).Frequency_Hz = frequency_Hz;
    datasets(i).Response_Hz_per_V = response_Hz_per_V;
    datasets(i).Phase_deg = phase_deg;
    datasets(i).MagnitudeSource = magnitude_source;
    datasets(i).FilterCompensated = false;
    datasets(i).PhaseMinus90Frequency_Hz = ...
        find_phase_crossing_log_frequency( ...
        frequency_Hz, phase_deg, phase_target_deg);

    fprintf('%s: %d个频点，幅值来自%s；未做滤波器补偿。\n', ...
        datasets(i).Label, numel(frequency_Hz), magnitude_source);
    if isfinite(datasets(i).PhaseMinus90Frequency_Hz)
        fprintf('  -90°相位交点 = %.9g Hz (%.6g MHz)\n', ...
            datasets(i).PhaseMinus90Frequency_Hz, ...
            datasets(i).PhaseMinus90Frequency_Hz/1e6);
    else
        fprintf(2, '  当前频率范围内没有检测到-90°相位交点。\n');
    end
end

%% 2. 按之前的双Y轴风格绘制对比图
fig = figure( ...
    'Color', 'w', ...
    'Name', '698 nm Pinzhun vs. JWS Laser Response', ...
    'Position', [100, 100, 950, 680]);
ax = axes(fig);
ax.Toolbar.Visible = 'off';
hold(ax, 'on');

yyaxis(ax, 'left');
magnitude_handles = gobjects(numel(datasets), 1);
for i = 1:numel(datasets)
    magnitude_handles(i) = plot(ax, ...
        datasets(i).Frequency_Hz/1e6, ...
        datasets(i).Response_Hz_per_V, ...
        'LineStyle', datasets(i).LineStyle, ...
        'Marker', datasets(i).Marker, ...
        'Color', magnitude_colors{i}, ...
        'LineWidth', 1.7, ...
        'MarkerSize', 5, ...
        'MarkerFaceColor', 'w', ...
        'DisplayName', sprintf('%s magnitude', datasets(i).Label));
end
set(ax, 'XScale', 'log', 'YScale', 'log');
ylabel(ax, 'Laser Response (Hz/V)', ...
    'FontWeight', 'bold', 'Color', magnitude_colors{1});
ax.YAxis(1).Color = magnitude_colors{1};

yyaxis(ax, 'right');
phase_handles = gobjects(numel(datasets), 1);
for i = 1:numel(datasets)
    phase_handles(i) = plot(ax, ...
        datasets(i).Frequency_Hz/1e6, ...
        datasets(i).Phase_deg, ...
        'LineStyle', datasets(i).LineStyle, ...
        'Marker', datasets(i).Marker, ...
        'Color', phase_colors{i}, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 4.5, ...
        'MarkerFaceColor', 'w', ...
        'DisplayName', sprintf('%s phase', datasets(i).Label));
end
ylabel(ax, 'Response Phase (deg)', ...
    'FontWeight', 'bold', 'Color', phase_colors{1});
ax.YAxis(2).Color = phase_colors{1};

yline(ax, phase_target_deg, ':', '-90 deg', ...
    'Color', [0.35, 0.35, 0.35], ...
    'LineWidth', 1.2, ...
    'LabelHorizontalAlignment', 'left', ...
    'HandleVisibility', 'off');

for i = 1:numel(datasets)
    crossing_Hz = datasets(i).PhaseMinus90Frequency_Hz;
    if ~isfinite(crossing_Hz)
        continue;
    end
    crossing_MHz = crossing_Hz/1e6;
    xline(ax, crossing_MHz, datasets(i).LineStyle, ...
        'Color', phase_colors{i}, ...
        'LineWidth', 1.3, ...
        'HandleVisibility', 'off');
    plot(ax, crossing_MHz, phase_target_deg, 'p', ...
        'Color', phase_colors{i}, ...
        'MarkerFaceColor', phase_colors{i}, ...
        'MarkerSize', 10, ...
        'HandleVisibility', 'off');
end

all_frequency_Hz = vertcat(datasets.Frequency_Hz);
all_phase_deg = vertcat(datasets.Phase_deg);
xlim(ax, [min(all_frequency_Hz), max(all_frequency_Hz)]/1e6);
phase_limits = [floor(min(all_phase_deg)/50)*50, ...
    max(0, ceil(max(all_phase_deg)/50)*50)];
ylim(ax, phase_limits);
phase_span = diff(phase_limits);

for i = 1:numel(datasets)
    crossing_Hz = datasets(i).PhaseMinus90Frequency_Hz;
    if ~isfinite(crossing_Hz)
        continue;
    end
    crossing_MHz = crossing_Hz/1e6;
    label_y = phase_target_deg - (0.045 + 0.07*(i-1))*phase_span;
    text(ax, crossing_MHz*1.035, label_y, ...
        sprintf('%s: %.4g MHz', datasets(i).ShortLabel, crossing_MHz), ...
        'Color', phase_colors{i}, ...
        'FontWeight', 'bold', ...
        'FontSize', 9, ...
        'HorizontalAlignment', 'left', ...
        'VerticalAlignment', 'top');
end

xlabel(ax, 'Modulation Frequency (MHz)', 'FontWeight', 'bold');
title(ax, '698 nm Pinzhun vs. JWS Laser Response (No Filter Compensation)', ...
    'FontSize', 12, 'FontWeight', 'bold');
grid(ax, 'on');
ax.XMinorGrid = 'on';
ax.GridAlpha = 0.22;
ax.MinorGridAlpha = 0.10;
ax.FontName = 'Arial';
ax.FontSize = 10;
ax.TickDir = 'in';
box(ax, 'on');
legend(ax, [magnitude_handles; phase_handles], ...
    'Location', 'southwest', 'NumColumns', 2);

%% 3. 保存图片、FIG、MAT和-90°交点汇总
time_str = char(datetime('now', 'Format', 'yyyyMMdd_HHmmss'));
file_prefix = 'Laser_Response_Comparison_698_Pinzhun_vs_JWS_NoFilterComp';
png_file = fullfile(script_dir, sprintf('%s_%s.png', file_prefix, time_str));
fig_file = fullfile(script_dir, sprintf('%s_%s.fig', file_prefix, time_str));
csv_file = fullfile(script_dir, sprintf('%s_%s.csv', file_prefix, time_str));
mat_file = fullfile(script_dir, sprintf('%s_%s.mat', file_prefix, time_str));

exportgraphics(fig, png_file, 'Resolution', 300);
savefig(fig, fig_file);

ComparisonTable = table( ...
    string({datasets.ShortLabel})', ...
    string({datasets.FileName})', ...
    logical([datasets.FilterCompensated])', ...
    [datasets.PhaseMinus90Frequency_Hz]', ...
    [datasets.PhaseMinus90Frequency_Hz]'/1e6, ...
    'VariableNames', { ...
        'Dataset', 'SourceFile', 'FilterCompensated', ...
        'PhaseMinus90Frequency_Hz', 'PhaseMinus90Frequency_MHz'});
writetable(ComparisonTable, csv_file);
save(mat_file, 'datasets', 'ComparisonTable', 'phase_target_deg');

disp(ComparisonTable);
fprintf('对比图片: %s\n', png_file);
fprintf('可编辑图: %s\n', fig_file);
fprintf('交点汇总: %s\n', csv_file);
fprintf('对比数据: %s\n', mat_file);

%% 局部函数
function crossing_frequency_Hz = find_phase_crossing_log_frequency( ...
        frequency_Hz, phase_deg, target_phase_deg)
%FIND_PHASE_CROSSING_LOG_FREQUENCY 在log10(f)上线性插值相位交点。
% 若存在多个交点，返回最低频率的一个。

    crossing_frequency_Hz = NaN;
    phase_offset = phase_deg - target_phase_deg;
    exact_index = find(abs(phase_offset) < 1e-9, 1, 'first');
    if ~isempty(exact_index)
        crossing_frequency_Hz = frequency_Hz(exact_index);
        return;
    end

    crossing_index = find( ...
        phase_offset(1:end-1).*phase_offset(2:end) < 0, 1, 'first');
    if isempty(crossing_index)
        return;
    end

    f1 = frequency_Hz(crossing_index);
    f2 = frequency_Hz(crossing_index + 1);
    phase1 = phase_deg(crossing_index);
    phase2 = phase_deg(crossing_index + 1);
    log_crossing_frequency = log10(f1) + ...
        (target_phase_deg - phase1) * (log10(f2) - log10(f1)) / ...
        (phase2 - phase1);
    crossing_frequency_Hz = 10^log_crossing_frequency;
end
